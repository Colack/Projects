export function helloWrd() {

    console.clear();

    helloWrd1();

}

function helloWrd1() {

    console.clear();

    console.log("##        ##");
    console.log("##        ##");
    console.log("##        ##");
    console.log("############");
    console.log("##        ##");
    console.log("##        ##");
    console.log("##        ##");

    setTimeout(helloWrd2, 500);

}

function helloWrd2() {

    console.clear();

    console.log("############");
    console.log("##          ");
    console.log("##          ");
    console.log("##########  ");
    console.log("##          ");
    console.log("##          ");
    console.log("############");    

    setTimeout(helloWrd3, 500);

}

function helloWrd3() {

    console.clear();

    console.log("##          ");
    console.log("##          ");
    console.log("##          ");
    console.log("##          ");
    console.log("##          ");
    console.log("##          ");
    console.log("############");   

    setTimeout(helloWrd4, 1000);

}

function helloWrd4() {

    console.clear();

    console.log(" ########## ");
    console.log("##        ##");
    console.log("##        ##");
    console.log("##        ##");
    console.log("##        ##");
    console.log("##        ##");
    console.log(" ########## ");   

    setTimeout(helloWrd5, 500);

}

function helloWrd5() {

    console.clear();

    console.log(" ##       ##");
    console.log(" ##       ##");
    console.log(" ##  ###  ##");
    console.log(" ## ## ## ##");
    console.log(" ## ## ## ##");
    console.log(" ## ## ## ##");
    console.log("  ###   ### ");    

    setTimeout(helloWrd6, 500);

}

function helloWrd6() {

    console.clear();

    console.log(" ########## ");
    console.log("##        ##");
    console.log("##        ##");
    console.log("##        ##");
    console.log("##        ##");
    console.log("##        ##");
    console.log(" ########## ");   

    setTimeout(helloWrd7, 500);

}

function helloWrd7() {

    console.clear();

    console.log("##          ");
    console.log("########### ");
    console.log("##        ##");
    console.log("##          ");
    console.log("##          ");
    console.log("##          ");
    console.log("##          ");   

    setTimeout(helloWrd8, 500);

}

function helloWrd8() {

    console.clear();

    console.log("##          ");
    console.log("##          ");
    console.log("##          ");
    console.log("##          ");
    console.log("##          ");
    console.log("##          ");
    console.log("############");  

    setTimeout(helloWrd9, 500);

}

function helloWrd9() {

    console.clear();

    console.log("########### ");
    console.log("##        ##");
    console.log("##        ##");
    console.log("##        ##");
    console.log("##        ##");
    console.log("##        ##");
    console.log("########### ");  

}
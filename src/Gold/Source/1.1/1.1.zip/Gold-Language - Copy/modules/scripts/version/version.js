var version = {
    major: 1,
    minor: 1
}

export { version };
// To be used later :)))))))))))))))))))))))))))))))))))))))))

var colorsOn = true; 
export { colorsOn };
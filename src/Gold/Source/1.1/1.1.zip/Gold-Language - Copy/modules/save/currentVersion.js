const currentVersion = 4;

export { currentVersion };
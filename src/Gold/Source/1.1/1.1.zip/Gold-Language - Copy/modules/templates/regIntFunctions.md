# Functions

fun - add, sub, mul, div, if, log, var, logVar, input, xLog, egg, shell, crack, kill, ifVar    
saveToVar - true/false     
val1    
val2   
slot    
slot1   
slot2   
type - =, >, <, !     
logvaluetrue    
logvaluefalse    
variableArea - Center, First, Last   

end - ALWAYS END YOUR PROGRAM WITH THIS!!!!    
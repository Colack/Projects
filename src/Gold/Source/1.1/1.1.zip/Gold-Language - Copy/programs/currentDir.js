var myGoldProgramDirectory = './program.gold';

export { myGoldProgramDirectory };
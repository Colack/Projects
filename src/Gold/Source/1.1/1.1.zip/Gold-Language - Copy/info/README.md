# Tutorials

**Wanting To Learn how to program using *Gold*?**

[Learning-Gold](https://github.com/Shining-Gold-Studios/Gold-Language/wiki)
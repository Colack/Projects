var myGoldProgram;
export { myGoldProgram };
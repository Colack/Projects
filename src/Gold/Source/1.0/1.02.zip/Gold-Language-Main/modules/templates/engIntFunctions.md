# Functions

execute - add, sub, mul, div, if, log, var, logVar   
saveToVariable - true/false   
value1   
value2   
variableSlot    
ifStatementType - =, >, <, !    
logIfValueTrue   
logIfValueFalse    
endProgram - ALWAYS END YOUR PROGRAM WITH THIS!!!!   
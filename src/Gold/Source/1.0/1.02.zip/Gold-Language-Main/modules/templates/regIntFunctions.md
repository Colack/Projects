# Functions

fun - add, sub, mul, div, if, log, var, logVar    
saveToVar - true/false     
val1    
val2   
slot    
type - =, >, <, !     
logvaluetrue    
logvaluefalse    
end - ALWAYS END YOUR PROGRAM WITH THIS!!!!    
var version = {
    major: 1,
    minor: 02
}

export { version };
export function randomNum(max) {

    return Math.floor(Math.random() * max);

}
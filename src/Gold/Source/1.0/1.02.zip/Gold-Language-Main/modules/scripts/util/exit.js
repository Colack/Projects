export function kill() {

    return process.exit(1);

}
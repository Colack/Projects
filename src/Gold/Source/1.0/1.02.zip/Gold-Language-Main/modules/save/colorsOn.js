// To be Used in 1.03

var colorsOn = true; 
export { colorsOn };
const currentVersion = 3;

export { currentVersion };
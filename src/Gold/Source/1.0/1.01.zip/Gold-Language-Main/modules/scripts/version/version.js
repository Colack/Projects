var version = {
    major: 1,
    minor: 01    
}

export { version };
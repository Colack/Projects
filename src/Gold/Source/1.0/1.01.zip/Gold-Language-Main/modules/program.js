var myGoldProgram; 
export { myGoldProgram };
// To be Used in 1.02

var colorsOn = true; 
export { colorsOn };
const currentVersion = 2;

export { currentVersion };
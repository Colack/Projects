# Image Information

- **Gold-Cover.png - Image used for Cover on Github**
- **Gold-3d.png - 3d Cover image for the language.**
- **Gold-2d.png - 2d Cover image for the language.**

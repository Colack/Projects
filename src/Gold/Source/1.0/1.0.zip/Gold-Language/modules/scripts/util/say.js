export function say(text) {

    console.log(text);

}

var version = {
    major: 1,
    minor: 0    
}

export { version };
import { goldLoad } from "../../interpreters/goldInt.js";
import { myGoldProgramArea, destination, currentError, goldExtensionCheck } from '../../util/index.js';

goldLoad(destination);
import { say } from '../util/say.js';

export function amIOn() {

    say('Yes. You are on.');

}
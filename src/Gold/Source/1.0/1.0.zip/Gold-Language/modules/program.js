var myGoldProgram = {
    name: "Example Gold Program",
    des: "An Example Gold Program for the README file.",
    ex: [
        {
            fun: "log",
            val1: "Hello World!",
            val2: "",
            logvaluetrue: "",
            logvaluefalse: "",
            type: ""
        }
    ]
};

export { myGoldProgram };